package version

var Version string
