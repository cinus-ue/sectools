# 倒序
# filename: invertedStr.py

dicts = {
    "name": "字符倒序",
    "crypto_name": "invertedStr",
    "key": False
}


def invertedStr(cryptostr):
    result = cryptostr[::-1]
    return result.encode()
