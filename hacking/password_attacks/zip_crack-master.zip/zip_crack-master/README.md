# zip_crack
zip压缩文件密码暴力破解

使用方法：

  python zip_crack -f file.zip -d dic.txt
