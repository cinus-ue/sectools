# 全部大写
# filename: upperStr.py

dicts = {
    "name": "全部大写",
    "crypto_name": "upperStr",
    "key": False
}


def upperStr(cryptostr):
    result = cryptostr.upper()
    return result.encode()
