## rust-stealer / Luca Stealer

## How to setup?
https://github.com/luca364/rust-stealer/wiki/Installation

# Functions:
### Wallet Stealer
  - AtomicWallet
  - Exodus
  - Electrum
  - Ethereum
  - Guarda
  - Coinomi
  - Armory
  - ZCash
  - JaxxWallet

------------

### Chromium Stealer
	edge
	chromium
	7star
	amigo
	brave
	centbrowser
	chedot
	chrome_canary
	coccoc
	dragon
	elements-browser
	epic-privacy-browser
	chrome
	kometa
	orbitum
	sputnik
	torchne
	ucozmedia
	vivaldi
	atom-mailru:
	operane
	opera-gx
	ChromePlus
	Iridium
	Iridium
	fenrir-inc
	catalinagroup
	Coowoo
	liebao
	qip-surf
	360browser

------------


### FireFox Stealer
  - Steals Passwords & Cookies from Firefox profiles.
------------

### Clipper
- XMR
- BNB
- TRX
- ETH
- BTC
- DOGE
- BCH
- LTC
- DASH
- XRP
- ADA
- TON
- NEO
- ETC
- SOL
- ZEC
- ALGO
- XLM
- IBAN

------------
### Browser Addon Stealer
	- EOS Authenticator
	-Bitwarden
	-KeePassXC
	-Dashlane
	-1Password
	-NordPass
	-Keeper
	-RoboForm
	-LastPass
	-BrowserPass
	-MYKI
	-Splikity
	-CommonKey
	-Zoho Vault
	-Norton Password Manager
	-Avira Password Manaager
	-Trezor Password Manager
	-MetaMask
	-TronLink
	-BinanceChain
	-Coin98
	-iWallet
	-Wombat
	-MEW CX
	-NeoLine
	-Terra Station
	-Keplr
	-Sollet
	-ICONex
	-KHC
	-TezBox
	-Byone
	-OneKey
	-DAppPlay
	-BitClip
	-Steem Keychain
	-Nash Extension
	-Hycon Lite Client
	-ZilPay
	-Leaf Wallet
	-Cyano Wallet
	-Cyano Wallet Pro
	-Nabox Wallet
	-Polymesh Wallet
	-Nifty Wallet
	-Liquality Wallet
	-Math Wallet
	-Coinbase Wallet
	-Clover Wallet
	-Yoroi
	-Guarda
	-EQUAL Wallet
	-BitApp Wallet
	-Auro Wallet
	-Saturn Wallet
	-Ronin Wallet
	-Exodus
	-Maiar DeFi Wallet
	-Nami
	-Eternl

------------
### Messenger Stealer
	- Discord
	- Element
	- ICQ
	- Skype
### Other Stealer

- Sensitive Files
- Steam
- UPlay
- Telegram

- Simple Anti VM


## Write Up's about the stealer
https://github.com/luca364/rust-stealer/wiki/Write-Up's


## I need help setting it up

Please try it yourself first, If you cant do it.
Write me https://t.me/Lxca1337



