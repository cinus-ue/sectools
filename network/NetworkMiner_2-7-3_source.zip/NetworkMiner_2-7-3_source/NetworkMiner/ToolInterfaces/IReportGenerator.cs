using System;
using System.Collections.Generic;
using System.Text;

namespace NetworkMiner.ToolInterfaces {

    public interface IReportGenerator {
        void ShowReport(NetworkMinerForm networkMinerForm);
    }
}
