#pragma GCC diagnostic push

#pragma GCC diagnostic ignored "-Wextra"
#pragma GCC diagnostic ignored "-Wsign-compare"
#pragma GCC diagnostic ignored "-Wcomment"
#pragma GCC diagnostic ignored "-Wparentheses"
#pragma GCC diagnostic ignored "-Wstrict-aliasing"
#pragma GCC diagnostic ignored "-Wunused-value"

#pragma GCC diagnostic ignored "-Wall"
#pragma GCC diagnostic ignored "-W"

#include "my_ev_common.h"
#include "ev.c"

#pragma GCC diagnostic pop
