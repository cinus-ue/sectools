### Quick `journalctl` output analysis with bash

```
$ curl -s https://raw.githubusercontent.com/snovvcrash/usbrip/master/quick/a.sh | bash
$ curl -sL https://git.io/Jvf60 | bash
$ wget -qO- https://raw.githubusercontent.com/snovvcrash/usbrip/master/quick/a.sh | bash
$ wget -qO- https://git.io/Jvf60 | bash
```
