package main

import "github.com/liamg/furious/cmd"

func main() {
	cmd.Execute()
}
