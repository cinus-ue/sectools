# 全部小写
# filename: lowerStr.py

dicts = {
    "name": "全部小写",
    "crypto_name": "lowerStr",
    "key": False
}


def lowerStr(cryptostr):
    result = cryptostr.lower()
    return result.encode()
