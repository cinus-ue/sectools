This folder contains files that have been copied from the wireshark wiki:

https://wiki.wireshark.org/SampleCaptures

These files have been distributed under the GPL, thanks a lot!
