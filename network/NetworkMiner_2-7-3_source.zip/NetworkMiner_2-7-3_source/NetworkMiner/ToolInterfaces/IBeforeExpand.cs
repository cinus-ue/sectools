﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetworkMiner.ToolInterfaces {
    public interface IBeforeExpand {
        void BeforeExpand();
    }

}
